{\rtf1\ansi\ansicpg1252\cocoartf2636
\cocoatextscaling0\cocoaplatform0{\fonttbl\f0\fmodern\fcharset0 CourierNewPSMT;\f1\fmodern\fcharset0 CourierNewPS-BoldMT;\f2\fmodern\fcharset0 CourierNewPS-ItalicMT;
}
{\colortbl;\red255\green255\blue255;\red0\green0\blue0;\red255\green255\blue255;\red59\green81\blue185;
\red38\green38\blue38;\red101\green40\blue139;\red100\green100\blue100;\red55\green124\blue30;\red137\green74\blue30;
\red154\green154\blue154;}
{\*\expandedcolortbl;;\cssrgb\c0\c0\c0;\cssrgb\c100000\c100000\c100000;\cssrgb\c29412\c41176\c77647;
\cssrgb\c20000\c20000\c20000;\cssrgb\c47843\c24314\c61569;\cssrgb\c46667\c46667\c46667;\cssrgb\c26667\c54902\c15294;\cssrgb\c61176\c36471\c15294;
\cssrgb\c66667\c66667\c66667;}
\margl1440\margr1440\vieww11520\viewh8400\viewkind0
\deftab720
\pard\pardeftab720\partightenfactor0

\f0\fs28 \cf2 \cb3 \expnd0\expndtw0\kerning0
\outl0\strokewidth0 \strokec4 #Use the code below to load the images and ground truth label TOS;\
\
import\strokec5  numpy \strokec4 as\strokec5  
\f1\b \strokec6 np
\f0\b0 \strokec5 \
\pard\pardeftab720\partightenfactor0
\cf2 \strokec6 data\strokec5  \strokec7 =\strokec5  
\f1\b \strokec6 np
\f0\b0 \strokec7 .\strokec5 load\strokec7 ('\strokec8 2023-11-15-cine-myo-masks-and-TOS.npy\strokec7 ',\strokec5  \strokec6 allow_pickle\strokec7 =\strokec9 True\strokec7 )\strokec5 \
\strokec6 mask_volume_0\strokec5  \strokec7 =\strokec5  \strokec6 data\strokec7 [\strokec9 0\strokec7 ]['\strokec8 cine_lv_myo_masks_cropped\strokec7 ']\strokec5  
\f2\i \strokec10 # Get the myocardium mask of slice 0. It should be a (H, W, n_frames) volume
\f0\i0 \strokec5 \
\strokec6 TOS_volume_0\strokec5  \strokec7 =\strokec5  \strokec6 data\strokec7 [\strokec9 0\strokec7 ]['\strokec8 TOS\strokec7 ']\strokec5  
\f2\i \strokec10 # Get the TOS curve of slice 0. It should be a (126, n_frames) 2D array
\f0\i0 \strokec5 \
}